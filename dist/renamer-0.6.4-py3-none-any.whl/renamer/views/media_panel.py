from pathlib import Path
from rich.markup import escape
from ..formatters.text_formatter import TextFormatter
from ..formatters.track_formatter import TrackFormatter
from ..formatters.formatter import FormatterApplier
from .media_panel_properties import MediaPanelProperties


class MediaPanelView:
    """View for assembling media data panels for display.

    This view aggregates multiple formatters to create comprehensive
    display panels for technical and catalog modes.
    """

    def __init__(self, extractor):
        self.extractor = extractor
        self._props = MediaPanelProperties(extractor)

    def file_info_panel(self) -> str:
        """Return formatted file info panel string"""
        sections = [
            self.file_info(),
            self.selected_data(),
            self.tmdb_data(),
            self.tracks_info(),
            self.filename_extracted_data(),
            self.metadata_extracted_data(),
            self.mediainfo_extracted_data(),
        ]
        return "\n\n".join("\n".join(section) for section in sections)

    def file_info(self) -> list[str]:
        data = [
            {
                "group": "File Info",
                "label": "File Info",
                "label_formatters": [TextFormatter.bold, TextFormatter.uppercase],
            },
            {
                "group": "File Info",
                "label": "Path",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.file_path,
            },
            {
                "group": "File Info",
                "label": "Size",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.file_size,
            },
            {
                "group": "File Info",
                "label": "Name",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.file_name,
            },
            {
                "group": "File Info",
                "label": "Modified",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.modification_time,
            },
            {
                "group": "File Info",
                "label": "Extension",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.extension_fileinfo,
            },
        ]
        return FormatterApplier.format_data_items(data)

    def tmdb_data(self) -> list[str]:
        """Return formatted TMDB data"""
        data = [
            {
                "label": "TMDB Data",
                "label_formatters": [TextFormatter.bold, TextFormatter.uppercase],
            },
            {
                "label": "ID",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.tmdb_id,
            },
            {
                "label": "Title",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.tmdb_title,
            },
            {
                "label": "Original Title",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.tmdb_original_title,
            },
            {
                "label": "Year",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.tmdb_year,
            },
            {
                "label": "Database Info",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.tmdb_database_info,
            },
            {
                "label": "URL",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.tmdb_url,
            }
        ]
        return FormatterApplier.format_data_items(data)

    def tracks_info(self) -> list[str]:
        """Return formatted tracks information"""
        data = [
            {
                "group": "Tracks Info",
                "label": "Tracks Info",
                "label_formatters": [TextFormatter.bold, TextFormatter.uppercase],
            }
        ]

        # Get video tracks
        video_tracks = self.extractor.get("video_tracks", "MediaInfo") or []
        for item in video_tracks:
            data.append(
                {
                    "group": "Tracks Info",
                    "label": "Video Track",
                    "value": item,
                    "value_formatters": TrackFormatter.format_video_track,
                    "display_formatters": [TextFormatter.green],
                }
            )

        # Get audio tracks
        audio_tracks = self.extractor.get("audio_tracks", "MediaInfo") or []
        for i, item in enumerate(audio_tracks, start=1):
            data.append(
                {
                    "group": "Tracks Info",
                    "label": f"Audio Track {i}",
                    "value": item,
                    "value_formatters": TrackFormatter.format_audio_track,
                    "display_formatters": [TextFormatter.yellow],
                }
            )

        # Get subtitle tracks
        subtitle_tracks = self.extractor.get("subtitle_tracks", "MediaInfo") or []
        for i, item in enumerate(subtitle_tracks, start=1):
            data.append(
                {
                    "group": "Tracks Info",
                    "label": f"Subtitle Track {i}",
                    "value": item,
                    "value_formatters": TrackFormatter.format_subtitle_track,
                    "display_formatters": [TextFormatter.magenta],
                }
            )

        return FormatterApplier.format_data_items(data)

    def metadata_extracted_data(self) -> list[str]:
        """Format metadata extraction data for the metadata panel"""
        data = [
            {
                "label": "Metadata Extraction",
                "label_formatters": [TextFormatter.bold, TextFormatter.uppercase],
            },
            {
                "label": "Title",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.metadata_title,
            },
            {
                "label": "Duration",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.metadata_duration,
            },
            {
                "label": "Artist",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.metadata_artist,
            },
        ]

        return FormatterApplier.format_data_items(data)

    def mediainfo_extracted_data(self) -> list[str]:
        """Format media info extraction data for the mediainfo panel"""
        data = [
            {
                "label": "Media Info Extraction",
                "label_formatters": [TextFormatter.bold, TextFormatter.uppercase],
            },
            {
                "label": "Duration",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_duration,
            },
            {
                "label": "Frame Class",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_frame_class,
            },
            {
                "label": "Resolution",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_resolution,
            },
            {
                "label": "Aspect Ratio",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_aspect_ratio,
            },
            {
                "label": "HDR",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_hdr,
            },
            {
                "label": "Audio Languages",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_audio_langs,
            },
            {
                "label": "Anamorphic",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_anamorphic,
            },
            {
                "label": "Extension",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_extension,
            },
            {
                "label": "3D Layout",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.mediainfo_3d_layout,
            },
        ]
        return FormatterApplier.format_data_items(data)

    def filename_extracted_data(self) -> list[str]:
        """Return formatted filename extracted data"""
        data = [
            {
                "label": "Filename Extracted Data",
                "label_formatters": [TextFormatter.bold, TextFormatter.uppercase],
            },
            {
                "label": "Order",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_order,
            },
            {
                "label": "Movie title",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_title,
            },
            {
                "label": "Year",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_year,
            },
            {
                "label": "Video source",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_source,
            },
            {
                "label": "Frame class",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_frame_class,
            },
            {
                "label": "HDR",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_hdr,
            },
            {
                "label": "Audio langs",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_audio_langs,
            },
            {
                "label": "Special info",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_special_info,
            },
            {
                "label": "Movie DB",
                "label_formatters": [TextFormatter.bold],
                "value": self._props.filename_movie_db,
            },
        ]

        return FormatterApplier.format_data_items(data)

    def selected_data(self) -> list[str]:
        """Return formatted selected data string"""
        import logging
        import os
        if os.getenv("FORMATTER_LOG"):
            frame_class = self.extractor.get("frame_class")
            audio_langs = self.extractor.get("audio_langs")
            logging.info(f"Selected data - frame_class: {frame_class!r}, audio_langs: {audio_langs!r}")
            # Also check from Filename source
            frame_class_filename = self.extractor.get("frame_class", "Filename")
            audio_langs_filename = self.extractor.get("audio_langs", "Filename")
            logging.info(f"From Filename - frame_class: {frame_class_filename!r}, audio_langs: {audio_langs_filename!r}")
        data = [
            {
                "label": "Selected Data",
                "label_formatters": [TextFormatter.bold, TextFormatter.uppercase],
            },
            {
                "label": "Order",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_order,
            },
            {
                "label": "Title",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_title,
            },
            {
                "label": "Year",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_year,
            },
            {
                "label": "Special info",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_special_info,
            },
            {
                "label": "Source",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_source,
            },
            {
                "label": "Frame class",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_frame_class,
            },
            {
                "label": "HDR",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_hdr,
            },
            {
                "label": "Audio langs",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_audio_langs,
            },
            {
                "label": "Database Info",
                "label_formatters": [TextFormatter.bold, TextFormatter.blue],
                "value": self._props.selected_database_info,
            }
        ]
        return FormatterApplier.format_data_items(data)
