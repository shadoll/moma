"""Media panel property methods using decorator pattern.

This module contains all the formatted property methods that return
display-ready values for the media panel view. Each property uses
decorators to apply formatting, similar to ProposedFilenameView.
"""

from rich.markup import escape
from ..formatters import (
    date_decorators,
    text_decorators,
    conditional_decorators,
)
from ..formatters.size_formatter import SizeFormatter
from ..formatters.date_formatter import DateFormatter
from ..formatters.extension_formatter import ExtensionFormatter
from ..formatters.text_formatter import TextFormatter
from ..formatters.duration_formatter import DurationFormatter
from ..formatters.special_info_formatter import SpecialInfoFormatter
from ..formatters.resolution_formatter import ResolutionFormatter


class MediaPanelProperties:
    """Formatted properties for media panel display.

    This class provides @property methods that return formatted values
    ready for display in the media panel. Each property applies the
    appropriate decorators for styling and formatting.
    """

    def __init__(self, extractor):
        self._extractor = extractor

    # ============================================================
    # File Info Properties
    # ============================================================

    @property
    @text_decorators.blue()
    def file_path(self) -> str:
        """Get file path formatted in blue."""
        return escape(str(self._extractor.get("file_path", "FileInfo")))

    @property
    @text_decorators.bold()
    @text_decorators.green()
    def file_size(self) -> str:
        """Get file size formatted as bold green human-readable size."""
        size = self._extractor.get("file_size", "FileInfo")
        return SizeFormatter.format_size_full(size) if size else ""

    @property
    @text_decorators.cyan()
    def file_name(self) -> str:
        """Get file name formatted in cyan."""
        return escape(str(self._extractor.get("file_name", "FileInfo")))

    @property
    @text_decorators.bold()
    @text_decorators.magenta()
    def modification_time(self) -> str:
        """Get modification time formatted as bold magenta date."""
        mtime = self._extractor.get("modification_time", "FileInfo")
        return DateFormatter.format_modification_date(mtime) if mtime else ""

    @property
    @text_decorators.green()
    def extension_fileinfo(self) -> str:
        """Get extension from FileInfo formatted in green."""
        ext = self._extractor.get("extension", "FileInfo")
        return ExtensionFormatter.format_extension_info(ext) if ext else ""

    # ============================================================
    # TMDB Properties
    # ============================================================

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def tmdb_id(self) -> str:
        """Get TMDB ID formatted in yellow."""
        return self._extractor.get("tmdb_id", "TMDB")

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def tmdb_title(self) -> str:
        """Get TMDB title formatted in yellow."""
        return self._extractor.get("title", "TMDB")

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def tmdb_original_title(self) -> str:
        """Get TMDB original title formatted in yellow."""
        return self._extractor.get("original_title", "TMDB")

    @property
    @conditional_decorators.wrap("Year: ")
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def tmdb_year(self) -> str:
        """Get TMDB year formatted in yellow."""
        return self._extractor.get("year", "TMDB")

    @property
    @text_decorators.yellow()
    def tmdb_database_info(self) -> str:
        """Get TMDB database info formatted in yellow."""
        db_info = self._extractor.get("movie_db", "TMDB")
        if not db_info:
            return "<None>"
        return SpecialInfoFormatter.format_database_info(db_info)

    @property
    @conditional_decorators.default("<None>")
    def tmdb_url(self) -> str:
        """Get TMDB URL formatted."""
        url = self._extractor.get("tmdb_url", "TMDB")
        return TextFormatter.format_url(url) if url else None

    # ============================================================
    # Metadata Extraction Properties
    # ============================================================

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def metadata_title(self) -> str:
        """Get metadata title formatted in grey."""
        return self._extractor.get("title", "Metadata")

    @property
    @text_decorators.grey()
    def metadata_duration(self) -> str:
        """Get metadata duration formatted in grey."""
        duration = self._extractor.get("duration", "Metadata")
        if not duration:
            return "Not extracted"
        return DurationFormatter.format_full(duration)

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def metadata_artist(self) -> str:
        """Get metadata artist formatted in grey."""
        return self._extractor.get("artist", "Metadata")

    # ============================================================
    # MediaInfo Extraction Properties
    # ============================================================

    @property
    @text_decorators.grey()
    def mediainfo_duration(self) -> str:
        """Get MediaInfo duration formatted in grey."""
        duration = self._extractor.get("duration", "MediaInfo")
        if not duration:
            return "Not extracted"
        return DurationFormatter.format_full(duration)

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def mediainfo_frame_class(self) -> str:
        """Get MediaInfo frame class formatted in grey."""
        return self._extractor.get("frame_class", "MediaInfo")

    @property
    @text_decorators.grey()
    def mediainfo_resolution(self) -> str:
        """Get MediaInfo resolution formatted in grey."""
        resolution = self._extractor.get("resolution", "MediaInfo")
        if not resolution:
            return "Not extracted"
        return ResolutionFormatter.format_resolution_dimensions(resolution)

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def mediainfo_aspect_ratio(self) -> str:
        """Get MediaInfo aspect ratio formatted in grey."""
        return self._extractor.get("aspect_ratio", "MediaInfo")

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def mediainfo_hdr(self) -> str:
        """Get MediaInfo HDR formatted in grey."""
        return self._extractor.get("hdr", "MediaInfo")

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def mediainfo_audio_langs(self) -> str:
        """Get MediaInfo audio languages formatted in grey."""
        return self._extractor.get("audio_langs", "MediaInfo")

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def mediainfo_anamorphic(self) -> str:
        """Get MediaInfo anamorphic formatted in grey."""
        return self._extractor.get("anamorphic", "MediaInfo")

    @property
    @text_decorators.grey()
    def mediainfo_extension(self) -> str:
        """Get MediaInfo extension formatted in grey."""
        ext = self._extractor.get("extension", "MediaInfo")
        if not ext:
            return "Not extracted"
        return ExtensionFormatter.format_extension_info(ext)

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def mediainfo_3d_layout(self) -> str:
        """Get MediaInfo 3D layout formatted in grey."""
        return self._extractor.get("3d_layout", "MediaInfo")

    # ============================================================
    # Filename Extraction Properties
    # ============================================================

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("Not extracted")
    def filename_order(self) -> str:
        """Get filename order formatted in yellow."""
        return self._extractor.get("order", "Filename")

    @property
    @text_decorators.grey()
    def filename_title(self) -> str:
        """Get filename title formatted in grey."""
        return self._extractor.get("title", "Filename") or ""

    @property
    @text_decorators.grey()
    def filename_year(self) -> str:
        """Get filename year formatted in grey."""
        return self._extractor.get("year", "Filename") or ""

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def filename_source(self) -> str:
        """Get filename source formatted in grey."""
        return self._extractor.get("source", "Filename")

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def filename_frame_class(self) -> str:
        """Get filename frame class formatted in grey."""
        return self._extractor.get("frame_class", "Filename")

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def filename_hdr(self) -> str:
        """Get filename HDR formatted in grey."""
        return self._extractor.get("hdr", "Filename")

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def filename_audio_langs(self) -> str:
        """Get filename audio languages formatted in grey."""
        return self._extractor.get("audio_langs", "Filename")

    @property
    @text_decorators.grey()
    def filename_special_info(self) -> str:
        """Get filename special info formatted in blue grey."""
        special_info = self._extractor.get("special_info", "Filename")
        if not special_info:
            return "Not extracted"
        return TextFormatter.blue(SpecialInfoFormatter.format_special_info(special_info))

    @property
    @text_decorators.grey()
    @conditional_decorators.default("Not extracted")
    def filename_movie_db(self) -> str:
        """Get filename movie DB formatted in grey."""
        return self._extractor.get("movie_db", "Filename")

    # ============================================================
    # Selected Data Properties
    # ============================================================

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def selected_order(self) -> str:
        """Get selected order formatted in yellow."""
        return self._extractor.get("order")

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def selected_title(self) -> str:
        """Get selected title formatted in yellow."""
        return self._extractor.get("title")

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def selected_year(self) -> str:
        """Get selected year formatted in yellow."""
        return self._extractor.get("year")

    @property
    @text_decorators.yellow()
    def selected_special_info(self) -> str:
        """Get selected special info formatted in yellow."""
        special_info = self._extractor.get("special_info")
        if not special_info:
            return "<None>"
        return SpecialInfoFormatter.format_special_info(special_info)

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def selected_source(self) -> str:
        """Get selected source formatted in yellow."""
        return self._extractor.get("source")

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def selected_frame_class(self) -> str:
        """Get selected frame class formatted in yellow."""
        return self._extractor.get("frame_class")

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def selected_hdr(self) -> str:
        """Get selected HDR formatted in yellow."""
        return self._extractor.get("hdr")

    @property
    @text_decorators.yellow()
    @conditional_decorators.default("<None>")
    def selected_audio_langs(self) -> str:
        """Get selected audio languages formatted in yellow."""
        return self._extractor.get("audio_langs")

    @property
    @text_decorators.yellow()
    def selected_database_info(self) -> str:
        """Get selected database info formatted in yellow."""
        db_info = self._extractor.get("movie_db")
        if not db_info:
            return "<None>"
        return SpecialInfoFormatter.format_database_info(db_info)
